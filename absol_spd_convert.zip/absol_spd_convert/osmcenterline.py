import xml.etree.ElementTree as ET
import csv
import os

# Adjust the file path to your environment
osm_file = os.path.expanduser('~/Desktop/car-racing/gnss_123_lane_with_polygon.osm')

# Verify if the file exists
if not os.path.exists(osm_file):
    print(f"OSM file not found at {osm_file}")
    exit()

# Parse the OSM file
tree = ET.parse(osm_file)
root = tree.getroot()

# Extract nodes and their coordinates
nodes = {}
for node in root.findall('node'):
    node_id = node.attrib['id']
    local_x = None
    local_y = None
    for tag in node.findall('tag'):
        if tag.attrib['k'] == 'local_x':
            local_x = tag.attrib['v']
        if tag.attrib['k'] == 'local_y':
            local_y = tag.attrib['v']
    if local_x is not None and local_y is not None:
        nodes[node_id] = {
            'local_x': local_x,
            'local_y': local_y
        }

# Extract ways
ways = {}
for way in root.findall('way'):
    way_id = way.attrib['id']
    nds = []
    for nd in way.findall('nd'):
        nds.append(nd.attrib['ref'])
    ways[way_id] = nds

# Extract relations with centerline information
relations = []
for relation in root.findall('relation'):
    for tag in relation.findall('tag'):
        if tag.attrib['k'] == 'type' and tag.attrib['v'] == 'lanelet':
            relation_id = relation.attrib['id']
            for member in relation.findall('member'):
                if member.attrib['type'] == 'way' and member.attrib['role'] == 'centerline':
                    centerline_way_id = member.attrib['ref']
                    if centerline_way_id in ways:
                        relations.append({
                            'relation_id': relation_id,
                            'way_id': centerline_way_id,
                            'nodes': ways[centerline_way_id]
                        })

# Define the output CSV file path
csv_file = os.path.expanduser('~/Desktop/car-racing/local_coordinates_tags.csv')

# Write to CSV
with open(csv_file, 'w', newline='') as csvfile:
    fieldnames = ['node_id', 'local_x', 'local_y']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    for relation in relations:
        for node_id in relation['nodes']:
            if node_id in nodes:
                writer.writerow({
                    'node_id': node_id,
                    'local_x': nodes[node_id]['local_x'],
                    'local_y': nodes[node_id]['local_y']
                })

print(f"CSV file created: {csv_file}")

