^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package autoware_external_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.13.0 (2019-12-03)
-------------------
* Update package.xml files to Format 2.
* Contributors: Joshua Whitley

1.12.0 (2019-07-12)
-------------------
* Adding CHANGELOG for autoware_external_msgs and autoware_map_msgs.
* Merge branch 'master' into package_moves
* Merge pull request #3 from amc-nu/master
  Message repository split up
* Add autoware_external_msgs package
  Signed-off-by: amc-nu <abrahammonrroy@yahoo.com>
* Contributors: Servando, amc-nu, Joshua Whitley
